<section class="py-4">
    <div class="container px-5">
        <h1>MY PROFILE</h1>
        <p>YOU CAN UPDATE OR CHANGE PASSWORD HERE.</p>
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card" style="min-height: 440px">
                    <div class="card-header" style="text-transform: uppercase; letter-spacing: 2px;">
                        MY PROFILE :: SETTINGS
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-10">
                                <b>Basic Information</b>
                                <div class="card mt-2">
                                <div class="card-body">
                                    asdad
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>